
import React, { useState, useEffect, useRef } from 'react';
import { db } from '../services/db';
import { PersonalTask, User } from '../types';
import { Plus, Check, Loader2, AlertCircle } from 'lucide-react';

export const MyTasks: React.FC<{ user: User }> = ({ user }) => {
  const [tasks, setTasks] = useState<PersonalTask[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    loadTasks();
  }, [user.id]);

  const loadTasks = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await db.getPersonalTasks(user.id);
      setTasks(data);
    } catch (err: any) {
      console.error("Error loading tasks:", err);
      if (err.code === 'PGRST205' || err.message?.includes('personal_tasks')) {
        setError("Table Missing");
      }
    } finally {
      setLoading(false);
    }
  };

  const addTask = async () => {
    const text = newTaskText.trim();
    if (!text || adding) return;
    
    setAdding(true);
    setError(null);
    try {
      const task = await db.addPersonalTask(user.id, text);
      if (task) {
        setTasks(prev => [task, ...prev]);
        setNewTaskText('');
        inputRef.current?.focus();
      }
    } catch (err: any) {
      console.error("Failed to add task:", err);
      if (err.code === 'PGRST205' || err.message?.includes('personal_tasks')) {
        setError("Table Missing");
      }
    } finally {
      setAdding(false);
    }
  };

  const completeTask = async (taskId: string) => {
    try {
      setTasks(prev => prev.filter(t => t.id !== taskId));
      await db.completePersonalTask(taskId);
    } catch (err) {
      console.error("Error completing task:", err);
      loadTasks();
    }
  };

  return (
    <div className="dashboard-card h-full flex flex-col overflow-hidden bg-[#151515] border-white/10 shadow-xl">
      <div className="p-4 border-b border-white/5 bg-white/[0.02]">
         <div className="relative">
            <input 
              ref={inputRef}
              type="text" 
              value={newTaskText}
              onChange={(e) => setNewTaskText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addTask()}
              placeholder={error === "Table Missing" ? "DATABASE OFFLINE..." : "Add task..."}
              disabled={adding || error === "Table Missing"}
              className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg py-2 pl-3 pr-10 text-xs text-white outline-none focus:border-brand-500 transition-all placeholder-gray-600 disabled:opacity-50"
            />
            <button 
              onClick={addTask}
              disabled={adding || !newTaskText.trim() || error === "Table Missing"}
              className="absolute right-1 top-1/2 -translate-y-1/2 p-1.5 text-muted hover:text-white disabled:opacity-50"
            >
              {adding ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
            </button>
         </div>
      </div>
      
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-1">
        {loading ? (
          <div className="flex justify-center py-10">
             <Loader2 size={16} className="animate-spin text-brand-500" />
          </div>
        ) : tasks.length === 0 ? (
          <div className="text-center py-20 opacity-20">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em]">No pending tasks</p>
          </div>
        ) : (
          tasks.map(task => (
            <div key={task.id} className="flex items-start gap-3 group py-2 border-b border-white/[0.02] last:border-0">
               <button 
                 onClick={() => completeTask(task.id)}
                 className="mt-0.5 w-4 h-4 rounded border border-white/10 flex items-center justify-center hover:border-brand-500 transition-all text-transparent hover:text-brand-500 bg-white/5"
               >
                 <Check size={10} strokeWidth={4} />
               </button>
               <span className="flex-1 text-[11px] text-gray-400 group-hover:text-white transition-colors leading-relaxed">{task.text}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

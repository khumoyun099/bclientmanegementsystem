import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://uiglmrczynfhkznxqlyv.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVpZ2xtcmN6eW5maGt6bnhxbHl2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU5ODQwNTMsImV4cCI6MjA4MTU2MDA1M30.Z-q3waqnTPNXHVVMmu6148evoe2NVG8BlWZ_FEfoyBI';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);